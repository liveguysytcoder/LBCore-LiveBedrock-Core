#pragma once
#include <iostream>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <set>
using namespace std;

extern uint32_t expectedSeq;
extern set<uint32_t> ackedSeqs;
const uint32_t MAX_SEQ = 0xFFFFFF;

void sendACKPacket(int sock,sockaddr_in clientAddr,uint32_t seqNum);
void checkAndSendNACK(int sock,sockaddr_in clientAddr,uint32_t receivedSeq);
void sendNACK(int sock,sockaddr_in clientAddr,uint32_t seqNum);