#include <iostream>
#include <vector>
#include <arpa/inet.h>

using namespace std;

extern const unsigned char RAKNET_MAGIC[16];

// function from reply file
extern void sendOpenConnectionReplyTwo(int sock, sockaddr_in clientAddr, unsigned short mtu);

// Decode Open Connection Request 2 (0x07)
void decodeOpenConnectionRequestTwo(int sock, sockaddr_in clientAddr, const vector<unsigned char>& data)
{
    //cout << "\n🔐 [Open Connection Request 2 Detected]\n";

    if (data.size() < 1 + 16 + 8) {
        cout << "[WARN] Invalid packet size for Open Connection Request 2\n";
        return;
    }

    // verify RakNet magic
    bool magicOK = true;
    for (int i = 0; i < 16; i++) {
        if (data[1 + i] != RAKNET_MAGIC[i])
            magicOK = false;
    }

    //cout << "RakNet Magic Valid: " << (magicOK ? "YES" : "NO") << endl;

    // Extract MTU
    unsigned short mtu = (data[data.size() - 10] << 8) | data[data.size() - 9];
    //cout << "MTU Size: " << mtu << endl;

    // Extract client GUID
    unsigned long long clientGUID = 0;
    for (int i = data.size() - 8; i < data.size(); i++)
        clientGUID = (clientGUID << 8) | data[i];

    //cout << "Client GUID: 0x" << hex << clientGUID << dec << endl;

    if (magicOK)
        sendOpenConnectionReplyTwo(sock, clientAddr, mtu);
}