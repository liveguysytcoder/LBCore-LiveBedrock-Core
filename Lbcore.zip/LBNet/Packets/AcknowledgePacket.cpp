#include <iostream>
#include <arpa/inet.h>
#include <sys/socket.h>
#include "AcknowledgePacket.h"
#include <set>
using namespace std;

set<uint32_t> ackedSeqs;
uint32_t expectedSeq = 0;

void sendACKPacket(int sock,sockaddr_in clientAddr,uint32_t seqNum) {
    if(ackedSeqs.count(seqNum)) return;
    ackedSeqs.insert(seqNum);
    
    if(ackedSeqs.size() > 1000)
       ackedSeqs.erase(ackedSeqs.begin());
    
    uint8_t ack[7];
    ack[0] = 0xC0;
    ack[1] = 0x00;
    ack[2] = 0x01;
    ack[3] = 0x00;
    ack[4] = seqNum & 0xFF;
    ack[5] = (seqNum >> 8) & 0xFF;
    ack[6] = (seqNum >> 16) & 0xFF;
    
    sendto(sock,ack,7,0,(sockaddr*)&clientAddr,sizeof(clientAddr));
}

void checkAndSendNACK(int sock,sockaddr_in clientAddr,uint32_t receivedSeq) {
    uint32_t gap = (receivedSeq - expectedSeq) & MAX_SEQ;
    if(gap > 0 && gap < 1000) {
        for(uint32_t i = 1; i < gap; i++) {
            uint32_t missing = (expectedSeq + i) & MAX_SEQ;
            if(!ackedSeqs.count(missing)) {
                sendNACK(sock,clientAddr,missing);
            }
        }
    }
    expectedSeq = (receivedSeq + 1) & MAX_SEQ;
}

void sendNACK(int sock,sockaddr_in clientAddr,uint32_t seqNum) {
    uint8_t nack[7];
    nack[0] = 0xA0;
    nack[1] = 0x00;
    nack[2] = 0x01;
    nack[3] = 0x00;
    nack[4] = seqNum & 0xFF;
    nack[5] = (seqNum >> 8) & 0xFF;
    nack[6] = (seqNum >> 16) & 0xFF;
    
    sendto(sock,nack,7,0,(sockaddr*)&clientAddr,sizeof(clientAddr));
}