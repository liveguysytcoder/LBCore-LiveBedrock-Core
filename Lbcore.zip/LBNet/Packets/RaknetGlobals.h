#ifndef RAKNET_GLOBALS_H
#define RAKNET_GLOBALS_H

#include <cstdint>

// RakNet magic bytes
extern const unsigned char RAKNET_MAGIC[16];

// Server unique ID
extern unsigned long long SERVER_GUID;

// RakNet sequencing counters
extern uint32_t g_nextFrameSetSeq;
extern uint32_t g_nextReliableIdx;
extern uint32_t g_nextOrderedIdx;

#endif