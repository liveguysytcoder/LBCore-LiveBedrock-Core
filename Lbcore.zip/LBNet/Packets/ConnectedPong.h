#pragma once
#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <cstdint>
using namespace std;

void sendConnectedPong(int sock,sockaddr_in clientAddr,uint64_t pingTime);