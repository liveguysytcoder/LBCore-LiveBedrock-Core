#include <iostream>
#include <vector>
#include <sys/socket.h>
#include <arpa/inet.h>
using namespace std;

void sendConnectionRequestAccepted(int sock,sockaddr_in clientAddr,uint16_t clientIndex,uint64_t sendPingTime);