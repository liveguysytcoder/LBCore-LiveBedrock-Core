#include "RaknetGlobals.h"

// RakNet Magic
const unsigned char RAKNET_MAGIC[16] = {
    0x00, 0xFF, 0xFF, 0x00,
    0xFE, 0xFE, 0xFE, 0xFE,
    0xFD, 0xFD, 0xFD, 0xFD,
    0x12, 0x34, 0x56, 0x78
};

// Unique server identifier
unsigned long long SERVER_GUID = 0x1122334455667788ULL;

// RakNet sequence counters
uint32_t g_nextFrameSetSeq = 1;
uint32_t g_nextReliableIdx = 1;
uint32_t g_nextOrderedIdx  = 1;
