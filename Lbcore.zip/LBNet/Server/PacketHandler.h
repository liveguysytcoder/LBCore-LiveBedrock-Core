#include <iostream>
#include <iomanip>
#include <vector>
#include <map>
#include <arpa/inet.h>

using namespace std;

extern map<uint32_t, vector<uint8_t>> sentPackets;
extern uint32_t globalReliableIndex;
extern uint32_t globalOrderingIndex;
extern uint32_t globalSeqNum;

// Main dispatcher
void decodePacket(int sock, sockaddr_in clientAddr, const vector<unsigned char>& data);