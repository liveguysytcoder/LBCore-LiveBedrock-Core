#include "ServerManager.h"
#include <iostream>

using namespace std;

std::string getServerProperties() {
    return "MCPE;Bedrock Debug Server;975;26.23;1;10;1122334455667788;Test World;Survival;1;19132;19133;";
}

int LBStart() {
    cout << "[ServerManager] Starting server...\n";

    start();  // This must be defined in another .cpp file (like Server.cpp)

    cout << "[ServerManager] Server stopped.\n";
    return 0;
}