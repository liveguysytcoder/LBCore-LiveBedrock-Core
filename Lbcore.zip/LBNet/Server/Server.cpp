#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstring>
#include <vector>
#include "Server.h"

using namespace std;

bool running = true;
int serverSocket = -1;
sockaddr_in serverAddress{};

sockaddr_in getServerAddress() {
    return serverAddress;
}

void start() {
    cout << "[INFO] Starting UDP listener on port 19132...\n";

    struct sockaddr_in serverAddr{}, clientAddr{};
    char buffer[2048];
    socklen_t addrLen = sizeof(clientAddr);

    // Create UDP socket
    serverSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (serverSocket < 0) {
        perror("[ERROR] Socket creation failed");
        return;
    }

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(19132);
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    if (::bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("[ERROR] Bind failed");
        close(serverSocket);
        return;
    }

    cout << "[READY] Listening for packets on port 19132...\n";

    while (running) {
        memset(buffer, 0, sizeof(buffer));

        ssize_t bytesReceived = recvfrom(
            serverSocket, buffer, sizeof(buffer), 0,
            (struct sockaddr*)&clientAddr, &addrLen
        );

        if (bytesReceived > 0) {
            cout << "\nReceived " << bytesReceived << " bytes from "
                 << inet_ntoa(clientAddr.sin_addr)
                 << ":" << ntohs(clientAddr.sin_port) << endl;

            vector<unsigned char> data(buffer, buffer + bytesReceived);
            decodePacket(serverSocket, clientAddr, data);
        }
    }

    cout << "[INFO] Server stopped.\n";

    if (serverSocket != -1) {
        close(serverSocket);
        serverSocket = -1;
    }
}

void stopServer() {
    cout << "[INFO] Stopping server...\n";
    running = false;
}