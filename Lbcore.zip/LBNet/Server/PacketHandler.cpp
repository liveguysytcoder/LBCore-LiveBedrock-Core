#include <iostream>
#include <iomanip>
#include <vector>
#include <map>
#include <arpa/inet.h>

#include "../Packets/UnconnectedPing.h"
#include "../Packets/OpenConnectionRequest1.h"
#include "../Packets/OpenConnectionRequest2.h"
#include "../Packets/FrameSetPacket.h"
#include "../Packets/AcknowledgePacket.h"
#include "../Packets/ConnectionRequest.h"
#include "../Packets/ConnectedPong.h"
#include "Clients.h"
#include "PacketHandler.h"
#include "../../LBBNet/Server/PacketHandler.h"

using namespace std;

map<uint32_t, vector<uint8_t>> sentPackets;
uint32_t globalReliableIndex = 0;
uint32_t globalOrderingIndex = 0;
uint32_t globalSeqNum = 0;

// Main dispatcher
void decodePacket(int sock, sockaddr_in clientAddr, const vector<unsigned char>& data)
{
    if (data.empty()) return;

    unsigned char packetID = data[0];

    cout << "\n[PacketHandler] Packet ID: 0x"
         << hex << setw(2) << setfill('0') << (int)packetID
         << dec << endl;

    switch (packetID)
    {
        case 0x01:
            decodeUnconnectedPing(sock, clientAddr, data);
            break;

        case 0x05:
            decodeOpenConnectionRequestOne(sock, clientAddr, data);
            break;

        case 0x07:
            decodeOpenConnectionRequestTwo(sock, clientAddr, data);
            break;

        case 0xC0: {
            uint32_t ackedSeq = data[4] | (data[5] << 8) | (data[6] << 16);
            sentPackets.erase(ackedSeq);
            cout << "[ACK] Received\n";
            break;
        }

        case 0xA0: {
            uint32_t missingSeq = data[4] | (data[5] << 8) | (data[6] << 16);
            if(sentPackets.count(missingSeq)) {
                sendto(sock,sentPackets[missingSeq].data(),sentPackets[missingSeq].size(),0,(sockaddr*)&clientAddr,sizeof(clientAddr));
                cout << "[NACK] Resent SeqNum =" << missingSeq << "\n";
            } else {
                cout << "[NACK] SeqNum =" << missingSeq << "not in buffer!\n";
            }
            break;
        }
            
        default:

            // RakNet FrameSet packets (0x80 - 0x8D)
            if ((packetID & 0xF0) == 0x80) {
                FrameSetPacket packet = decodeFrameSetPacket(data.data(),data.size());
                printFrameSetPacket(packet);
                
                sendACKPacket(sock,clientAddr,packet.sequenceNumber);
                checkAndSendNACK(sock,clientAddr,packet.sequenceNumber);
                
                for(auto& frame : packet.frames) {
                    cout << "[Frame] ID: 0x" << hex << (int)frame.buffer[0] << dec << "\n";
                    switch(frame.buffer[0]) {
                        case 0x09: {
                            uint16_t clientIndex = addClient(clientAddr);
                            decodeConnectionRequest(sock,frame.buffer.data(),frame.buffer.size(),clientAddr,clientIndex);
                            break;
                        }
                        case 0x13:
                            cout << "NewIncomingConnection packet had arrived!!!\n";
                            break;
                        case 0x15:
                            removeClient(clientAddr);
                            break;
                        case 0x00: {
                            uint64_t pingTime = 0;
                            for(int i = 1;i <= 8;i++)
                                pingTime = (pingTime << 8) | frame.buffer[i];
                            sendConnectedPong(sock,clientAddr,pingTime);
                            break;
                        }
                        case 0x03:
                            cout << "[RakNet] Connected Pong received\n";
                            break;
                        case 0xFE: {
                            cout << "[Minecraft] Protocol Packet Received!\n";
                            vector<uint8_t> bedrockData(frame.buffer.begin(), frame.buffer.end());
                            handleBedrockPacket(sock, clientAddr, bedrockData);
                            break;
                        }
                        default:
                            cout << "Unknown Packet from inner frame\n";
                            break;
                    }
                }
            }
            else
            {
                cout << "[PacketHandler] Unknown packet. Raw bytes:\n";

                for (unsigned char b : data)
                    printf("%02X ", b);

                cout << endl;
            }

            break;
    }
}