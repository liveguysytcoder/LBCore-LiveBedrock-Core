#include <iostream>
#include <map>
#include <string>
#include <arpa/inet.h>
#include <sys/socket.h>
#include "Clients.h"

using namespace std;

uint16_t nextClientIndex = 0;
map<string, uint16_t> clients;

string getClientKey(sockaddr_in clientAddr) {
    char ip[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &clientAddr.sin_addr, ip, sizeof(ip));
    return string(ip) + ":" + to_string(ntohs(clientAddr.sin_port));
}

uint16_t addClient(sockaddr_in clientAddr) {
    string key = getClientKey(clientAddr);
    if (clients.count(key)) {
        return clients[key];
    }
    uint16_t index = nextClientIndex++;
    clients[key] = index;
    return index;
}

void removeClient(sockaddr_in clientAddr) {
    clients.erase(getClientKey(clientAddr));
}

bool isClientConnected(sockaddr_in clientAddr) {
    return clients.count(getClientKey(clientAddr)) > 0;
}