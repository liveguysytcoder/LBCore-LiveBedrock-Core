#include <iostream>
#include <map>
#include <string>
#include <arpa/inet.h>
#include <sys/socket.h>

using namespace std;

extern map<string, uint16_t> clients;
extern uint16_t nextClientIndex;

string getClientKey(sockaddr_in clientAddr);
uint16_t addClient(sockaddr_in clientAddr);
void removeClient(sockaddr_in clientAddr);
bool isClientConnected(sockaddr_in clientAddr);