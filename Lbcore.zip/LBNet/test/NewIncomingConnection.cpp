#include <iostream>
#include <stdint.h>
#include <arpa/inet.h>

using namespace std;

// external functions from other modules
void decodeConnectionRequest(int sock, sockaddr_in clientAddr, const uint8_t* data, size_t len);
void sendNetworkSettingsFrameSet(int sock, sockaddr_in clientAddr);

void decodeNewIncomingConnection() {
    
}