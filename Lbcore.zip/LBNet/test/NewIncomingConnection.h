#pragma once

#include <stdint.h>
#include <arpa/inet.h>

// Decode RakNet FrameSet packets (0x80 - 0x8D)
void decodeFrameSet(
    int sock,
    sockaddr_in clientAddr,
    const uint8_t* data,
    size_t len
);