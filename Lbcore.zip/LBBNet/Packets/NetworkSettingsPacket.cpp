#include "NetworkSettingsPacket.h"
#include "../../LBNet/Packets/FrameSetPacket.h"
#include "../../LBNet/Server/PacketHandler.h"
#include "DataTypeHelper.h"
#include <iostream>
#include <vector>
#include <sys/socket.h>
#include <arpa/inet.h>
using namespace std;

void sendNetworkSettings(int sock, sockaddr_in clientAddr) {
    // Layer 1: NetworkSettings packet content
    vector<uint8_t> packet;
    packet.push_back(0x8F);
    writeShort(packet, 1);
    writeShort(packet, 1);
    writeBool(packet, false);
    packet.push_back(0x00);
    writeFloat(packet, 0.0f);

    // Layer 2: Batch wrapper
    vector<uint8_t> payload;
    payload.push_back(0xFE);
    writeVarInt (payload, (uint32_t)packet.size());
    payload.insert(payload.end(), packet.begin(), packet.end());

    printNetworkSettingsLayers(packet, payload);

    Frame frame;
    frame.Reliability     = 3;
    frame.isSplit         = false;
    frame.reliableIndex   = globalReliableIndex++;
    frame.orderingIndex   = globalOrderingIndex++;
    frame.orderingChannel = 0;
    frame.buffer          = payload;

    FrameSetPacket wrapper;
    wrapper.flags          = 0x84;
    wrapper.sequenceNumber = globalSeqNum++;
    wrapper.frames.push_back(frame);

    printEncodedFrameSetPacket(wrapper);

    vector<uint8_t> encoded = encodeFrameSetPacket(wrapper);

    sendto(sock, encoded.data(), encoded.size(), 0,
           (sockaddr*)&clientAddr, sizeof(clientAddr));

    cout << "Sent NetworkSettings(" << encoded.size() << " bytes)\n";
    cout << "Buffer (hex):\n  ";
    for (size_t i = 0; i < encoded.size(); i++)
        printf("%02x ", encoded[i]);
    printf("\n");
}

void printNetworkSettingsLayers(const vector<uint8_t>& packet, const vector<uint8_t>& payload) {
    // Layer 1
    cout << "===========================================\n";
    cout << "NetworkSettings Packet (Layer 1)\n";
    cout << "===========================================\n";
    cout << "  Packet ID:               0x8F\n";
    cout << "  CompressionThreshold:    " << (*(uint16_t*)(packet.data() + 1)) << "\n";
    cout << "  CompressionAlgorithm:    " << (*(uint16_t*)(packet.data() + 3)) << "\n";
    cout << "  ClientThrottleEnabled:   " << (packet[5] ? "true" : "false") << "\n";
    cout << "  ClientThrottleThreshold: " << (int)packet[6] << "\n";
    cout << "  ClientThrottleScalar:    " << (*(float*)(packet.data() + 7)) << "\n";
    cout << "  Size: " << packet.size() << " bytes\n";
    cout << "===========================================\n";

    // Layer 2 — read real values from payload bytes
    // payload[0] = 0xFE marker
    // payload[1..n] = VarInt length
    // payload[n+1..] = packet bytes
    size_t offset = 1; // skip 0xFE
    uint32_t varlen = 0;
    int shift = 0;
    while (offset < payload.size()) {
        uint8_t b = payload[offset++];
        varlen |= (uint32_t)(b & 0x7F) << shift;
        if (!(b & 0x80)) break;
        shift += 7;
    }

    cout << "===========================================\n";
    cout << "Batch Wrapper (Layer 2)\n";
    cout << "===========================================\n";
    cout << "  Batch Marker:           0x" << hex << (int)payload[0] << dec << "\n";
    cout << "  Packet Length (VarInt): " << varlen << "\n";
    cout << "  Total Size:             " << payload.size() << " bytes\n";
    cout << "===========================================\n";
}