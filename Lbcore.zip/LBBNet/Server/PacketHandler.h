#pragma once
#include <iostream>
#include <iomanip>
#include <vector>
#include <sys/socket.h>
#include <arpa/inet.h>
#include "../../LBNet/Server/Server.h"
using namespace std;

// Decode varint, advances offset
uint32_t readVarint(const vector<uint8_t>& data, size_t& offset);
void handleBedrockPacket(int sock, sockaddr_in clientAddr, const vector<uint8_t>& data);