#include "PacketHandler.h"
#include <iostream>
#include <iomanip>
#include <vector>
#include "../Packets/DataTypeHelper.h"
#include "../Packets/NetworkSettingsPacket.h"
#include <sys/socket.h>
#include <arpa/inet.h>
#include "../../LBNet/Server/Server.h"
using namespace std;

void handleBedrockPacket(int sock, sockaddr_in clientAddr, const vector<uint8_t>& data) {
    if (data.empty()) return;

    size_t offset = 0;

    readUByte  (data, offset);          // skip 0xFE
    uint32_t length   = readVarInt(data, offset);  // batch length
    uint32_t packetID = readVarInt(data, offset);  // packet ID

    cout << "[Bedrock] Packet ID: 0x"
         << hex << setw(2) << setfill('0') << packetID
         << dec << " Length: " << length << "\n";

    switch (packetID) {
        case 0xC1: {
            uint32_t protocolVersion = readUIntBE(data, offset);  // Big-Endian int32
            cout << "[Bedrock] RequestNetworkSettings protocol=" << protocolVersion << "\n";
            sendNetworkSettings(sock, clientAddr);
            break;
        }

        case 0x01:
            cout << "[Bedrock] Login\n";
            // handleLogin(sock, clientAddr, data, offset);
            break;

        case 0x08:
            cout << "[Bedrock] ResourcePackClientResponse\n";
            break;

        default:
            cout << "[Bedrock] Unknown packet ID: 0x"
                 << hex << packetID << dec << "\n";
            break;
    }
}