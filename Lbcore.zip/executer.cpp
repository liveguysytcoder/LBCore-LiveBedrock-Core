#include <iostream>
#include "LBNet/Server/ServerManager.h"
#include "LBBNet/Server/ServerManager.h"

int main() {
    LBBStart();
    LBStart();
    return 0;
}